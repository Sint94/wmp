export function setDocumentTitle (state, { title }) {
  state.title = title
}

export function setSystemLanguage (state, { lang }) {
  state.lang = lang
}

export function setSideMenu (state, { visibility }) {
  state.menu = visibility
}
