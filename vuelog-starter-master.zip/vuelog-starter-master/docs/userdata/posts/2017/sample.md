title: This is a sample title
category: docs
date: 2017-09-22
------------------------------------
Welcome to the **sample** post written in *markdown*!

<!-- zh-CN:+ -->  
This will show if the language is set to Mandarin

<!-- zh-CN:- -->